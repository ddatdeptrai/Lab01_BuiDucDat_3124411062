﻿using System;

namespace BaiTap14
{
    // Lớp NhanVien quản lý thông tin và tính lương
    class NhanVien
    {
        public string HoTen { get; set; }
        public double MucLuong { get; set; }
        public int SoNgayVang { get; set; }

        // Nhập thông tin nhân viên
        public void Nhap()
        {
            Console.Write("Nhap ho ten nhan vien: ");
            HoTen = Console.ReadLine();

            Console.Write("Nhap muc luong co ban (VND): ");
            MucLuong = double.Parse(Console.ReadLine());

            Console.Write("Nhap so ngay vang: ");
            SoNgayVang = int.Parse(Console.ReadLine());
        }

        // Tính lương thực lãnh: Lương = Mức lương - (Số ngày vắng * 100.000)
        public double TinhLuong()
        {
            double luongThucLanh = MucLuong - (SoNgayVang * 100000);
            return luongThucLanh < 0 ? 0 : luongThucLanh; // Tránh trường hợp lương âm nếu vắng quá nhiều
        }

        // Xuất thông tin và kết quả lương
        public void Xuat()
        {
            Console.WriteLine("\n--- THONG TIN & LUONG NHAN VIEN ---");
            Console.WriteLine($"Ho va ten:          {HoTen}");
            Console.WriteLine($"Muc luong co ban:   {MucLuong:N0} VND");
            Console.WriteLine($"So ngay vang:       {SoNgayVang}");
            Console.WriteLine($"Luong thuc lanh:    {TinhLuong():N0} VND");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            NhanVien nv = new NhanVien();

            Console.WriteLine("=== NHAP THONG TIN NHAN VIEN ===");
            nv.Nhap();

            nv.Xuat();

            Console.ReadKey();
        }
    }
}