﻿
using System;
namespace Bai2
{
    class Bai2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap ho ten cua ban");
            String hoten=Console.ReadLine();
            Console.WriteLine("Chao ban " + hoten);
        }
    }
}