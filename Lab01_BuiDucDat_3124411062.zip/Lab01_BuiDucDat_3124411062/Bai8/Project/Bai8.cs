﻿using System;

namespace BaiTap8
{
    
    class HoanDoi
    {
     
        public void HoanVi(ref double a, ref double b)
        {
            double temp = a;
            a = b;
            b = temp;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
          
            Console.Write("Nhap so thuc a: ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Nhap so thuc b: ");
            double b = double.Parse(Console.ReadLine());

            Console.WriteLine($"\nTruoc khi hoan vi: a = {a}, b = {b}");

            
            HoanDoi hd = new HoanDoi();
            hd.HoanVi(ref a, ref b);

            Console.WriteLine($"Sau khi hoan vi:   a = {a}, b = {b}");

            Console.ReadKey();
        }
    }
}