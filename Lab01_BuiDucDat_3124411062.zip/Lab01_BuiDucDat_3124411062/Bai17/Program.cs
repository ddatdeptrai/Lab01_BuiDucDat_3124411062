﻿using System;
using System.Collections.Generic;

class Matrix
{
    private int n;
    private int m;
    private int[,] A;

    // 1. Sinh ngẫu nhiên mảng A[nxm] trong đoạn [10, 100]
    public void SinhNgauNhien(int rows, int cols)
    {
        n = rows;
        m = cols;
        A = new int[n, m];
        Random rand = new Random();

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                // rand.Next(min, max + 1) để lấy giá trị trong [10, 100]
                A[i, j] = rand.Next(10, 101);
            }
        }
    }

    // 2. In mảng ra màn hình
    public void InMang()
    {
        Console.WriteLine($"\n--- Ma tran A [{n}x{m}] ---");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                Console.Write($"{A[i, j],5}");
            }
            Console.WriteLine();
        }
    }

    // 3. Trả về hai mảng: mảng các số chẵn và mảng các số lẻ
    public (int[] MangChan, int[] MangLe) TachChanLe()
    {
        List<int> chan = new List<int>();
        List<int> le = new List<int>();

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                if (A[i, j] % 2 == 0)
                {
                    chan.Add(A[i, j]);
                }
                else
                {
                    le.Add(A[i, j]);
                }
            }
        }

        return (chan.ToArray(), le.ToArray());
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Nhap so dong (n): ");
        int n = int.Parse(Console.ReadLine() ?? "0");

        Console.Write("Nhap so cot (m): ");
        int m = int.Parse(Console.ReadLine() ?? "0");

        Matrix matrix = new Matrix();

        // 1. Sinh ngẫu nhiên mảng
        matrix.SinhNgauNhien(n, m);

        // 2. In mảng ra màn hình
        matrix.InMang();

        // 3. Tách và in 2 mảng chẵn, lẻ
        var (mangChan, mangLe) = matrix.TachChanLe();

        Console.WriteLine($"\nMang cac so chan ({mangChan.Length} phan tu):");
        Console.WriteLine(string.Join(" ", mangChan));

        Console.WriteLine($"\nMang cac so le ({mangLe.Length} phan tu):");
        Console.WriteLine(string.Join(" ", mangLe));
    }
}