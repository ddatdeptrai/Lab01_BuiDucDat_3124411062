﻿using System;
using System.Collections.Generic;

namespace BaiTap15
{
    class XuLyMang
    {
        // a. Nhập mảng gồm n phần tử
        public int[] NhapMang(int n)
        {
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhap phan tu a[{i}]: ");
                a[i] = int.Parse(Console.ReadLine());
            }
            return a;
        }

        // b. In mảng ra màn hình
        public void InMang(int[] a)
        {
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i] + " ");
            }
            Console.WriteLine();
        }

        
        public void TimMaxMin(int[] a, out int max, out int min)
        {
            max = a[0];
            min = a[0];

            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] > max)
                {
                    max = a[i];
                }

                if (a[i] < min)
                {
                    min = a[i];
                }
            }
        }

       
        public bool KiemTraNguyenTo(int n)
        {
            if (n < 2)
            {
                return false;
            }

            for (int i = 2; i * i <= n; i++)
            {
                if (n % i == 0)
                {
                    return false;
                }
            }

            return true;
        }

        // d. Trả về mảng các số nguyên tố
        public int[] LayMangSoNguyenTo(int[] a)
        {
            List<int> dsNguyenTo = new List<int>();

            for (int i = 0; i < a.Length; i++)
            {
                if (KiemTraNguyenTo(a[i]))
                {
                    dsNguyenTo.Add(a[i]);
                }
            }

            return dsNguyenTo.ToArray(); // Chuyển List thành mảng int[] để trả về
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            XuLyMang xl = new XuLyMang();

            // Nhập kích thước mảng
            Console.Write("Nhap so phan tu n: ");
            int n = int.Parse(Console.ReadLine());

            // Câu a: Nhập mảng
            int[] arr = xl.NhapMang(n);

            // Câu b: In mảng
            Console.Write("\nMang vua nhap la: ");
            xl.InMang(arr);

            // Câu c: Tìm Max và Min
            xl.TimMaxMin(arr, out int max, out int min);
            Console.WriteLine($"Gia tri lon nhat la: {max}");
            Console.WriteLine($"Gia tri nho nhat la: {min}");

            // Câu d: Trả về mảng các số nguyên tố
            int[] mangSNT = xl.LayMangSoNguyenTo(arr);
            Console.Write("Mang cac so nguyen to: ");
            if (mangSNT.Length == 0)
            {
                Console.WriteLine("Khong co so nguyen to nao trong mang.");
            }
            else
            {
                xl.InMang(mangSNT);
            }

            Console.ReadKey();
        }
    }
}