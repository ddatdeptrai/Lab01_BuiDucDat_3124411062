﻿using System;

namespace BaiTap7
{
   
    class SoHoc
    {
     
        public bool KiemTraNguyenTo(int n)
        {
            if (n < 2)
            {
                return false;
            }

            for (int i = 2; i*i <= n; i++)
            {
                if (n % i == 0)
                {
                    return false; 
                }
            }

            return true;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap so nguyen n: ");
            int n = int.Parse(Console.ReadLine());

            SoHoc sh = new SoHoc();
            bool ketQua = sh.KiemTraNguyenTo(n);

            if (ketQua)
            {
                Console.WriteLine( + n + " la so nguyen to");
            }
            else
            {
                Console.WriteLine(+ n + " khong la so nguyen to");
            }

            Console.ReadKey();
        }
    }
}