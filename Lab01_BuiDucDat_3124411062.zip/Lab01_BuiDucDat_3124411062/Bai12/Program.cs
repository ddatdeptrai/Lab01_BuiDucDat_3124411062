﻿using System;

namespace BaiTap12
{
    class XuLyChuoi
    {
        // 1. Chuyển sang ký tự thường
        public string ChuyenThanhThuong(string s)
        {
            return s.ToLower();
        }

        // 2. Chuyển sang ký tự hoa
        public string ChuyenThanhHoa(string s)
        {
            return s.ToUpper();
        }

        // 3. Đếm số từ trong chuỗi
        public int DemSoTu(string s)
        {
            if (string.IsNullOrWhiteSpace(s))
            {
                return 0;
            }

            // Tách các từ dựa trên khoảng trắng và tự động loại bỏ các khoảng trắng thừa liên tiếp
            string[] tu = s.Split(new char[] { ' ', '\t', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return tu.Length;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap chuoi gom nhieu tu: ");
            string input = Console.ReadLine();

            XuLyChuoi xl = new XuLyChuoi();

            // Gọi các phương thức xử lý
            string chuoiThuong = xl.ChuyenThanhThuong(input);
            string chuoiHoa = xl.ChuyenThanhHoa(input);
            int soTu = xl.DemSoTu(input);

            // In kết quả
            Console.WriteLine("\n--- KET QUA ---");
            Console.WriteLine($"Chuoi ky tu thuong: {chuoiThuong}");
            Console.WriteLine($"Chuoi ky tu hoa:    {chuoiHoa}");
            Console.WriteLine($"So tu trong chuoi:  {soTu}");

            Console.ReadKey();
        }
    }
}