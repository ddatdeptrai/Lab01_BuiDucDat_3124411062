﻿using System;

namespace BaiTap9
{

    class ToanHoc
    {
       
        public void TimMaxMin(double a, double b, double c, out double max, out double min)
        {
          
            max = a;
            if (b > max) max = b;
            if (c > max) max = c;

          
            min = a;
            if (b < min) min = b;
            if (c < min) min = c;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
          
            Console.Write("Nhap so thuc thu nhat: ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Nhap so thuc thu hai: ");
            double b = double.Parse(Console.ReadLine());

            Console.Write("Nhap so thuc thu ba: ");
            double c = double.Parse(Console.ReadLine());

          
            ToanHoc th = new ToanHoc();
            th.TimMaxMin(a, b, c, out double maxVal, out double minVal);

         
            Console.WriteLine($"\nGia tri lon nhat (Max): {maxVal}");
            Console.WriteLine($"Gia tri nho nhat (Min): {minVal}");

            Console.ReadKey();
        }
    }
}