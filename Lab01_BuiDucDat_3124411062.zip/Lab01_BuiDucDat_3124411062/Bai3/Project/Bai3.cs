﻿using System;
namespace Bai3
{
    class Bai3
    {
          static void Main(string[] args)
        {
            Console.WriteLine("Nhap so nguyen x: ");
            int x = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhap so nguyen y");
            int y = int.Parse(Console.ReadLine());
            int ketqua = (int)Math.Pow(x, y);
            Console.WriteLine("Ket qua " + x +" mu " + y + " la " + ketqua);
    }
}
}
