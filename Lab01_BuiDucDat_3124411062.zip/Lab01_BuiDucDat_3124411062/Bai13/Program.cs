﻿using System;

namespace BaiTap13
{
    // Lớp SinhVien lưu trữ thông tin sinh viên
    class SinhVien
    {
        // Các thuộc tính (properties)
        public string MaSV { get; set; }
        public string HoTen { get; set; }
        public string DiaChi { get; set; }
        public int NamThuMay { get; set; }

        // Phương thức nhập thông tin
        public void Nhap()
        {
            Console.Write("Nhap ma sinh vien: ");
            MaSV = Console.ReadLine();

            Console.Write("Nhap ho ten: ");
            HoTen = Console.ReadLine();

            Console.Write("Nhap dia chi: ");
            DiaChi = Console.ReadLine();

            Console.Write("Nhap sinh vien nam thu may (1, 2, 3, 4,...): ");
            NamThuMay = int.Parse(Console.ReadLine());
        }

        // Phương thức xuất thông tin
        public void Xuat()
        {
            Console.WriteLine("\n--- THONG TIN SINH VIEN ---");
            Console.WriteLine($"Ma sinh vien:       {MaSV}");
            Console.WriteLine($"Ho va ten:          {HoTen}");
            Console.WriteLine($"Dia chi:            {DiaChi}");
            Console.WriteLine($"Sinh vien nam thu:  {NamThuMay}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Khởi tạo đối tượng 1 sinh viên
            SinhVien sv = new SinhVien();

            // Nhập thông tin sinh viên
            Console.WriteLine("=== NHAP THONG TIN SINH VIEN ===");
            sv.Nhap();

            // Xuất thông tin sinh viên
            sv.Xuat();

            Console.ReadKey();
        }
    }
}