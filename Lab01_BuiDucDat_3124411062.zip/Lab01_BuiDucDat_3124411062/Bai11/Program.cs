﻿using System;

namespace BaiTap11
{
    // Lớp chứa phương thức xử lý chuỗi
    class XuLyChuoi
    {
        // Phương thức đảo ngược chuỗi
        public string DaoNguocChuoi(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return s;
            }

            // Chuyển chuỗi thành mảng ký tự để đảo thứ tự
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);

            // Chuyển mảng ký tự ngược lại thành chuỗi
            return new string(charArray);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap chuoi can dao nguoc: ");
            string input = Console.ReadLine();

            XuLyChuoi xl = new XuLyChuoi();
            string ketQua = xl.DaoNguocChuoi(input);

            Console.WriteLine($"Chuoi sau khi dao nguoc: {ketQua}");

            Console.ReadKey();
        }
    }
}