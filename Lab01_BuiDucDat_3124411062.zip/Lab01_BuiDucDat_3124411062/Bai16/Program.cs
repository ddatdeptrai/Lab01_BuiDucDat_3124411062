﻿using System;

namespace BaiTap16
{
    class QuanLyDanhSach
    {
        // Nhập mảng họ tên
        public string[] NhapHoTen(int n)
        {
            string[] ds = new string[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhap ho ten nguoi thu {i + 1}: ");
                ds[i] = Console.ReadLine();
            }
            return ds;
        }

        // Sắp xếp mảng theo thứ tự tăng dần theo bảng chữ cái (A -> Z)
        public void SapXepTangDan(string[] ds)
        {
            Array.Sort(ds);
        }

        // In danh sách ra màn hình
        public void InDanhSach(string[] ds)
        {
            for (int i = 0; i < ds.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {ds[i]}");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            QuanLyDanhSach ql = new QuanLyDanhSach();

            Console.Write("Nhap so luong nguoi n: ");
            int n = int.Parse(Console.ReadLine());

            // Nhập mảng
            string[] danhSach = ql.NhapHoTen(n);

            // Sắp xếp tăng dần
            ql.SapXepTangDan(danhSach);

            // In kết quả
            Console.WriteLine("\n--- DANH SACH SAU KHI SAP XEP TANG DAN ---");
            ql.InDanhSach(danhSach);

            Console.ReadKey();
        }
    }
}