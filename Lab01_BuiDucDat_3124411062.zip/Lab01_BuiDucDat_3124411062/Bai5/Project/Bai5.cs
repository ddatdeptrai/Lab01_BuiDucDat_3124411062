﻿using System;

namespace Bai5
{
    class Bai5
    {
        static void Main(string[] args)
        {
            double x = 0, y = 0;
            bool daNhap = false; // Biến kiểm tra xem đã nhập x, y chưa
            int chon = 0;

            do
            {
                Console.WriteLine(" --- MENU --- ");
                Console.WriteLine("1. Nhap hai gia tri so thuc cho x, y");
                Console.WriteLine("2. Tinh x^y");
                Console.WriteLine("3. Tinh can bac 2 cua x va y");
                Console.WriteLine("4. Thoat");
                Console.Write("Chon chuc nang: ");

                if (!int.TryParse(Console.ReadLine(), out chon))
                {
                    Console.WriteLine("Loi: Vui long chon tu 1 den 4!");
                    continue;
                }

                switch (chon)
                {
                    case 1:
                        Console.Write("Nhap so thuc x: ");
                        double.TryParse(Console.ReadLine(), out x);
                        Console.Write("Nhap so thuc y: ");
                        double.TryParse(Console.ReadLine(), out y);
                        daNhap = true;
                        Console.WriteLine("Da nhap xong x va y!");
                        break;

                    case 2:
                        if (!daNhap)
                        {
                            Console.WriteLine("Vui long chon 1 de nhap x, y truoc!");
                        }
                        else
                        {
                            double ketQuaLuyThua = Math.Pow(x, y);
                            Console.WriteLine(" Ket qua " + x + "^" + y + "la" +ketQuaLuyThua);
                        }
                        break;

                    case 3:
                        if (!daNhap)
                        {
                            Console.WriteLine("Vui long chon 1 de nhap x, y truoc!");
                        }
                        else
                        {
                           
                            if (x < 0)
                                Console.WriteLine("x am, khong tinh duoc can bac 2!");
                            else
                                Console.WriteLine("ket qua can bac 2 x la " + Math.Sqrt(x));

                            if (y < 0)
                                Console.WriteLine("y am, khong tinh duoc can bac 2!");
                            else
                                Console.WriteLine("ket qua can bac 2 y la " + Math.Sqrt(y));
                        }
                        break;

                    case 4:
                        Console.WriteLine("Thoat chuong trinh.");
                        break;

                    default:
                        Console.WriteLine("Lựa chon khong hop le! Vui long chon tu 1 den 4.");
                        break;
                }

            } while (chon != 4);
        }
    }
}