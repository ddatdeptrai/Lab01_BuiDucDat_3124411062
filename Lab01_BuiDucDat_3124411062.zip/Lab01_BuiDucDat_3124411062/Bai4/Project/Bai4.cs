﻿using System;

namespace Bai4
{
    class Bai4
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap so nguyen x: ");
            bool isXValid = int.TryParse(Console.ReadLine(), out int x);

            Console.Write("Nhap so nguyen y: ");
            bool isYValid = int.TryParse(Console.ReadLine(), out int y);

            // Kiểm tra cụ thể từng trường hợp lỗi
            if (!isXValid && !isYValid)
            {
                Console.WriteLine("Loi: Ca x va y deu khong phai la so nguyen!");
            }
            else if (!isXValid)
            {
                Console.WriteLine("Loi: x khong phai la so nguyen!");
            }
            else if (!isYValid)
            {
                Console.WriteLine("Loi: y khong phai la so nguyen!");
            }
            else
            {
                int ketqua = (int)Math.Pow(x, y);
                Console.WriteLine("ket qua " + x + " mu " + y + " la " +ketqua);
            }
        }
    }
}