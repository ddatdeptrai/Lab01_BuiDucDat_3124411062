﻿using System;

namespace BaiTap10
{
    // Lớp chứa phương thức xử lý chuỗi
    class XuLyChuoi
    {
        // Phương thức kiểm tra chuỗi đối xứng
        public bool KiemTraDoiXung(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return true; // Chuỗi rỗng được coi là đối xứng
            }

            int left = 0;
            int right = s.Length - 1;

            // So sánh từng cặp ký tự từ 2 đầu tiến vào giữa
            while (left < right)
            {
                if (s[left] != s[right])
                {
                    return false; // Có cặp ký tự khác nhau -> không đối xứng
                }
                left++;
                right--;
            }

            return true; // Tất cả đều khớp -> chuỗi đối xứng
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap chuoi can kiem tra: ");
            string str = Console.ReadLine();

            XuLyChuoi xl = new XuLyChuoi();
            bool ketQua = xl.KiemTraDoiXung(str);

            if (ketQua)
            {
                Console.WriteLine($"Chuoi \"{str}\" la chuoi doi xung (Palindrome).");
            }
            else
            {
                Console.WriteLine($"Chuoi \"{str}\" khong phai la chuoi doi xung.");
            }

            Console.ReadKey();
        }
    }
}