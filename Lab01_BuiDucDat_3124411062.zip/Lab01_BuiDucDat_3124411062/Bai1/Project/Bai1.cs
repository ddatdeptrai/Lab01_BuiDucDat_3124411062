﻿using System;
namespace Bai1
{
    class Bai1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nhap ho ten cua ban");
            String hoten=Console.ReadLine();
            Console.WriteLine("Ho va ten cua ban la" + hoten);
        }
    }
}